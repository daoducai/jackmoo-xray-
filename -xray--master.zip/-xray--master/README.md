## 网络跳跃大佬的一键脚本

大佬停更了，简单改了一下，简单好用。

## 一键脚本


`bash <(curl -sL https://raw.githubusercontent.com/a31663835/-xray-/master/xray.sh)`









